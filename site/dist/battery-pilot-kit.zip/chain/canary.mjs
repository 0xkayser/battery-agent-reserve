// Private single-operator canary. Financial commands require an explicit execution flag.
import {existsSync,readFileSync,mkdirSync,chmodSync,statSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {getTransferSolInstruction} from '@solana-program/system';
import {kit,token,subscriptions,RPC,GENESIS,PROGRAM,USDC,POLICY,hash,rpc,account,bytes,
 requireMainnet,addresses,setupInstructions,paymentInstructions,revokeInstruction,signedTransaction,
 chainState,programArtifact,guardPolicy,withdrawalInstructions,decodeToken,decodeDelegation,excessRefundAmount} from './reserve.mjs';
import {budgetPrice} from './budget.mjs';
import {durableJson,driveTransaction,verifyConfirmation} from './settlement.mjs';
const root=fileURLToPath(new URL('..',import.meta.url)),name=process.env.BATTERY_CANARY_NAME??'canary';
if(!/^[a-z][a-z0-9-]{0,47}$/.test(name))throw Error('Invalid isolated canary name');
const state=join(root,'mainnet-state',name);
const read=p=>JSON.parse(readFileSync(p,'utf8'));
function runtimeResult(file,job){
 const report=read(file);
 if(report.schema!=='battery.runtime-job/1'||report.cluster!=='mainnet'||report.job!==job||report.checkpoint?.body?.results?.length!==1)
  throw Error('Invalid integrated runtime result');
 execFileSync('python3',['-c','import json,sys;from core import verify_checkpoint;verify_checkpoint(json.load(open(sys.argv[1]))["checkpoint"])',file],{cwd:root,stdio:'pipe'});
 const r=report.checkpoint.body.results[0];
 if(r.id!==job||r.receipt!=='local:'+job||r.output?.input?.observation?.genesisHash!==GENESIS||r.output?.input?.observation?.cluster!=='mainnet')
  throw Error('Result/job/cluster identity mismatch');
 return hash(Buffer.from(JSON.stringify(r)));
}
async function signer(name){
 const path=join(state,name+'-key.json');
 if(!existsSync(path))await kit.writeKeyPairSigner(await kit.generateKeyPairSigner(true),path);
 if((statSync(path).mode&0o077)!==0)throw Error('Private key permissions must be0600');
 return kit.createKeyPairSignerFromBytes(Uint8Array.from(read(path)));
}
async function feeQuote(ixs,payer){
 const lifetime=(await rpc('getLatestBlockhash',[{commitment:'confirmed'}])).value;
 let m=kit.createTransactionMessage({version:0});m=kit.setTransactionMessageFeePayerSigner(payer,m);
 m=kit.setTransactionMessageLifetimeUsingBlockhash({...lifetime,lastValidBlockHeight:BigInt(lifetime.lastValidBlockHeight)},m);
 m=kit.appendTransactionMessageInstructions(ixs,m);
 const encoded=Buffer.from(kit.getCompiledTransactionMessageEncoder().encode(kit.compileTransactionMessage(m))).toString('base64');
 const fee=(await rpc('getFeeForMessage',[encoded,{commitment:'confirmed'}])).value;
 if(!Number.isSafeInteger(fee)||fee<0||fee>POLICY.maxFeeLamports)throw Error('Unavailable/excessive fee quote');
 return {fee,lifetime};
}
async function prepare(owner,worker){
 const artifact=await programArtifact(),svm=read(join(root,'evidence/reserve-svm.json'));
 if(svm.programSha256!==artifact.sha256||svm.passed!==15||svm.failed!==0)throw Error('Reviewed localSVM binary mismatch');
 const price=await budgetPrice();
 const a=await addresses(owner,worker);
 const rents={};for(const size of [106,187,165])rents[size]=await rpc('getMinimumBalanceForRentExemption',[size]);
 const expiry=Math.floor(Date.now()/1000)+POLICY.validSeconds;
 const setup=await setupInstructions(owner,worker,a,expiry);
 setup.push(getTransferSolInstruction({source:owner,destination:worker.address,amount:1_000_000n}));
 const fee=(await feeQuote(setup,owner)).fee;
 // Worker receives0.001SOL from the funded operator, included in the0.008SOL total.
 const setupCeiling=rents[106]+rents[187]+rents[165]+1_000_000+POLICY.maxFeeLamports*8+POLICY.gasFloorLamports;
 if(setupCeiling>POLICY.gasFundingLamports)throw Error('Rent/fee allocation no longer fits funded gas');
 // Sender may pay to create the owner USDC ATA plus two transfer fees. Bound these explicitly.
 const senderLamportAllowance=rents[165]+2*POLICY.maxFeeLamports;
 const costAtMaxPrice=POLICY.reserveUsdc/1e6+(POLICY.gasFundingLamports+senderLamportAllowance)/1e9*POLICY.maxSolPriceUsdc;
 if(costAtMaxPrice>POLICY.budgetUsdc/1e6)throw Error('Budget exceeded');
 const plan={schema:'battery.canary-plan/1',createdAt:new Date().toISOString(),cluster:'mainnet',genesisHash:GENESIS,
  rpc:RPC,program:PROGRAM,mint:USDC,programSha256:artifact.sha256,deploymentSlot:artifact.deploymentSlot,
  upgradeAuthority:artifact.upgradeAuthority,addresses:a,policy:POLICY,rentLamports:rents,setupFeeQuoteLamports:fee,
  senderLamportAllowance,costAtMaxSolPriceUsdc:costAtMaxPrice,price,
  costAtObservedPriceUsdc:POLICY.reserveUsdc/1e6+(POLICY.gasFundingLamports+senderLamportAllowance)/1e9*price.solUsdc,
  boundary:'Dedicated local operator wallet. Fixed1USDC cumulative worker allowance;2USDC floor on3USDC deposit only if no other delegations.0.01USDC per-result transfers are test settlements to our worker, not model-provider billing. Owner can revoke/change/withdraw. No vault/token launch.',
  status:'unfunded-no-mainnet-transactions'};
 const file=join(state,'plan.json');if(existsSync(file)){
  const old=read(file);if(old.addresses.owner!==a.owner||old.addresses.worker!==a.worker||old.programSha256!==plan.programSha256)throw Error('Existing reviewed plan differs; inspect, do not overwrite');
 }else durableJson(file,plan);
 console.log(JSON.stringify(plan,null,2));
}
async function main(){
 if(process.env.BATTERY_CANARY_LOCK!=='1')throw Error('Use python3 chain/canary.py for kernel single-operator lock');
 const [command,...flags]=process.argv.slice(2);
 if(!['prepare','status','setup','run','revoke','return-address','refund-extra','verify-guards','withdraw','authorize-job','pay-job','verify-job'].includes(command))throw Error('Unsupported canary command');
 if(['setup','run','revoke','refund-extra','verify-guards','withdraw','pay-job'].includes(command)&&!flags.includes('--execute-budget-5-usdc'))throw Error('Financial command disabled: explicit --execute-budget-5-usdc required after funding');
 mkdirSync(state,{recursive:true,mode:0o700});chmodSync(state,0o700);
 if(command!=='prepare'&&!existsSync(join(state,'plan.json')))throw Error('Prepare and review the canary plan first');
 const owner=await signer('owner'),worker=await signer('worker');
 requireMainnet(await rpc('getGenesisHash'));
 if(command==='prepare')return prepare(owner,worker);
 const plan=read(join(state,'plan.json')),a=await addresses(owner,worker);
 if(JSON.stringify(a)!==JSON.stringify(plan.addresses)||JSON.stringify(POLICY)!==JSON.stringify(plan.policy))throw Error('Plan/key/policy mismatch');
 const artifact=await programArtifact();if(artifact.sha256!==plan.programSha256)throw Error('Program upgraded since localSVM review; stop');
 if(command==='return-address'){
  const destination=kit.address(flags[0]);if([a.owner,a.worker].includes(destination))throw Error('Use explicit external return wallet');
  if(plan.returnAddress&&plan.returnAddress!==destination)throw Error('Return address already bound; inspect rather than overwrite');
  plan.returnAddress=destination;durableJson(join(state,'plan.json'),plan);
  console.log(JSON.stringify({returnAddress:destination,mainnetSigning:false}));return;
 }
 if(command==='status'){
  console.log(JSON.stringify({owner:a.owner,worker:a.worker,ownerSolLamports:(await rpc('getBalance',[a.owner])).value,
   sourceExists:!!await account(a.sourceAta),delegationExists:!!await account(a.delegation),mainnetSigning:false},null,2));return;
 }
 if(command==='authorize-job'){
  await budgetPrice();
  const job=flags[0];if(!/^research-00[123]$/.test(job))throw Error('Bounded job required');
  const existing=existsSync(join(state,'outbox.json'))?read(join(state,'outbox.json')):{};
  if(!existing.setup?.receipt)throw Error('Confirmed setup required before model generation');
  if(existing.revoke||existing['return-owner']||existing['return-worker'])throw Error('Canary closed; no new model task authorized');
  for(const [id,row] of Object.entries(existing))if(!row.receipt)throw Error('Reconcile uncertain payment before another model call');
  const s=await chainState(a);if(!s.delegation)throw Error('No active onchain allowance');
  const d=decodeDelegation(s.delegation,a);
  if(d.expiryTs!==0n&&d.expiryTs<=BigInt(Math.floor(Date.now()/1000)))throw Error('Onchain allowance expired');
  const fee=(await feeQuote(await paymentInstructions(worker,a,POLICY.jobUsdc,'0'.repeat(64),job),worker)).fee;
  guardPolicy({balanceUsdc:s.reserveUsdc,remainingUsdc:s.remainingUsdc,amountUsdc:POLICY.jobUsdc,gasLamports:s.gasLamports,feeLamports:fee});
  console.log(JSON.stringify({schema:'battery.job-authorization/1',cluster:'mainnet',job,
   amountUsdc:POLICY.jobUsdc,reserveUsdc:s.reserveUsdc,remainingUsdc:s.remainingUsdc,
   gasLamports:s.gasLamports,feeQuoteLamports:fee,observedAt:new Date().toISOString(),
   mainnetSigning:false,meaning:'Dated pre-task check; payment checks balances and policy again'}));return;
 }
 if(command==='verify-job'){
  const job=flags[0];if(!/^research-00[123]$/.test(job))throw Error('Bounded job required');
  const rows=read(join(state,'outbox.json')),row=rows[job];
  if(!row?.receipt||row.amountUsdc!==POLICY.jobUsdc)throw Error('Finalized bounded payment required');
  const resultHash=runtimeResult(flags[1],job);
  if(row.resultHash!==resultHash||!Buffer.from(row.wire,'base64').includes(Buffer.from(`BATTERY:v1:${job}:${resultHash}`)))throw Error('Finalized payment/result hash mismatch');
  const tx=await rpc('getTransaction',[row.signature,{encoding:'base64',commitment:'finalized',maxSupportedTransactionVersion:0}]);
  const result=verifyConfirmation(row,tx);
  if(JSON.stringify(result)!==JSON.stringify(row.receipt))throw Error('Saved payment receipt differs');
  console.log(JSON.stringify(result));return;
 }
 if(!flags.includes('--execute-budget-5-usdc'))throw Error('Financial command disabled: explicit --execute-budget-5-usdc required after funding');
 if(['setup','run','pay-job'].includes(command))await budgetPrice();
 const outboxFile=join(state,'outbox.json'),outbox=existsSync(outboxFile)?read(outboxFile):{};
 const save=()=>durableJson(outboxFile,outbox);
 const execute=async(id,ixs,payer,amountUsdc=0,resultHash=null,withdrawTo=null)=>{
  if(outbox[id]&&(outbox[id].amountUsdc!==amountUsdc||outbox[id].resultHash!==resultHash))throw Error('Existing settlement intent changed');
  if(outbox[id]?.receipt)return outbox[id].receipt;
  for(const [other,row] of Object.entries(outbox))if(other!==id&&!row.receipt)throw Error('Another transaction uncertain; reconcile it first');
  return driveTransaction({id,store:outbox,save,rpc,afterSend:()=>{
   if((command==='pay-job'||id==='research-002')&&flags.includes('--crash-after-send'))process.exit(74);
  },prepare:async()=>{
   const {fee,lifetime}=await feeQuote(ixs,payer);
   const bal=(await rpc('getBalance',[payer.address,{commitment:'confirmed'}])).value;
   if(amountUsdc&&!withdrawTo){const s=await chainState(a);guardPolicy({balanceUsdc:s.reserveUsdc,remainingUsdc:s.remainingUsdc,
    amountUsdc,gasLamports:s.gasLamports,feeLamports:fee});}
   else if(bal-fee<POLICY.gasFloorLamports)throw Error('Owner gas floor denied');
   const tx=await signedTransaction(ixs,payer,{...lifetime,lastValidBlockHeight:BigInt(lifetime.lastValidBlockHeight)});
   const wire=kit.getBase64EncodedWireTransaction(tx);if(Buffer.from(wire,'base64').length>1232)throw Error('Transaction exceeds packet bound');
   const sim=await rpc('simulateTransaction',[wire,{encoding:'base64',sigVerify:true,commitment:'confirmed'}]);
   if(!sim.value||sim.value.err!==null)throw Error('Preflight simulation failed; no broadcast');
   return {signature:kit.getSignatureFromTransaction(tx),wire,lastValidBlockHeight:lifetime.lastValidBlockHeight,
    feeLamports:fee,amountUsdc,resultHash,owner:withdrawTo?payer.address:a.owner,worker:withdrawTo??a.worker,preparedAt:new Date().toISOString()};
  }});
 };
 if(command==='refund-extra'){
  if(!plan.returnAddress)throw Error('Bound user-bound return wallet required');
  if(outbox.setup)throw Error('Excess refund only before setup');
  const s=await chainState(a),authority=await account(a.authority);
  const amount=outbox['refund-extra']?.amountUsdc??excessRefundAmount({...s,authority});
  if(!Number.isSafeInteger(amount)||amount<1||amount>POLICY.budgetUsdc-POLICY.reserveUsdc)throw Error('Refund must only remove excess above the reviewed3USDC reserve');
  if(s.delegation||authority||s.receiverUsdc!==0||s.gasLamports!==0)throw Error('Excess refund requires fresh dedicated accounts');
  const [destination]=await token.findAssociatedTokenPda({owner:plan.returnAddress,mint:USDC,tokenProgram:token.TOKEN_PROGRAM_ADDRESS});
  decodeToken(await account(destination),plan.returnAddress);
  const receipt=await execute('refund-extra',await withdrawalInstructions(owner,a.sourceAta,plan.returnAddress,amount),owner,amount,hash(Buffer.from(plan.returnAddress)),plan.returnAddress);
  if((await chainState(a)).reserveUsdc!==POLICY.reserveUsdc)throw Error('Reserve after excess refund mismatch');
  console.log(JSON.stringify({receipt,returnedTo:plan.returnAddress,reserveUsdc:POLICY.reserveUsdc}));
 }else if(command==='setup'){
  if(!plan.returnAddress)throw Error('Bind user-bound return wallet with return-address before financial setup');
  if(outbox.setup?.receipt){console.log(JSON.stringify(outbox.setup.receipt));return;}
  if(!outbox.setup){
   const s=await chainState(a),ownerSol=(await rpc('getBalance',[a.owner])).value;
   if(s.reserveUsdc!==POLICY.reserveUsdc||s.receiverUsdc!==0||s.delegation||await account(a.authority)||s.gasLamports!==0)
    throw Error('Only fresh dedicated accounts with exactly3USDC may initialize; unexpected prior authority/balances');
   const refundedFee=outbox['refund-extra']?.receipt?.feeLamports??0;
   if(ownerSol<POLICY.gasFundingLamports-refundedFee||ownerSol>POLICY.gasFundingLamports+POLICY.maxFeeLamports)throw Error('Fund exactly0.008SOL for the reviewed canary; only confirmed excess-refund fee may reduce it');
  }
  const expiry=Math.floor(Date.now()/1000)+POLICY.validSeconds;
  const ixs=await setupInstructions(owner,worker,a,expiry);
  ixs.push(getTransferSolInstruction({source:owner,destination:worker.address,amount:1_000_000n}));
  const receipt=await execute('setup',ixs,owner);
  const s=await chainState(a);if(s.remainingUsdc!==POLICY.allowanceUsdc||s.reserveUsdc!==POLICY.reserveUsdc)throw Error('Setup state mismatch');
  console.log(JSON.stringify({receipt,reserveUsdc:s.reserveUsdc,remainingUsdc:s.remainingUsdc}));
 }else if(command==='pay-job'){
  if(!outbox.setup?.receipt)throw Error('Confirmed setup required');
  if(outbox.revoke||outbox['return-owner']||outbox['return-worker'])throw Error('Canary closed; payment refused');
  const [job,file]=flags;if(!/^research-00[123]$/.test(job)||!file)throw Error('Bounded job and durable result path required');
  const resultHash=runtimeResult(file,job);
  const receipt=await execute(job,await paymentInstructions(worker,a,POLICY.jobUsdc,resultHash,job),worker,POLICY.jobUsdc,resultHash);
  console.log(JSON.stringify(receipt));
 }else if(command==='run'){
  if(!outbox.setup?.receipt)throw Error('Confirmed setup required');
  const reportPath=join(root,'evidence/mainnet-agent.json'),report=read(reportPath);
  if(report.cluster!=='mainnet'||report.experiment?.completedTasks!==3||report.experiment?.duplicateModelCalls!==0)throw Error('Verified owned mainnet researcher report required');
  const results=report.checkpoint.body.results;
  // Validate Python's canonical checkpoint serialization and all evidence relationships.
  execFileSync('python3',[join(root,'verify_evidence.py'),reportPath],{stdio:'pipe'});
  for(let i=0;i<3;i++){
   const job=`research-00${i+1}`,r=results[i];
   if(r?.id!==job||r.output?.input?.observation?.genesisHash!==GENESIS)throw Error('Mainnet research result mismatch');
   const resultHash=hash(Buffer.from(JSON.stringify(r)));
   await execute(job,await paymentInstructions(worker,a,POLICY.jobUsdc,resultHash,job),worker,POLICY.jobUsdc,resultHash);
  }
  const s=await chainState(a),paid=POLICY.jobs*POLICY.jobUsdc;
  if(s.reserveUsdc!==POLICY.reserveUsdc-paid||s.receiverUsdc!==paid||s.remainingUsdc!==POLICY.allowanceUsdc-paid)throw Error('Final exact balances mismatch');
  const proof={schema:'battery.mainnet-canary/1',observedAt:new Date().toISOString(),cluster:'mainnet',genesisHash:GENESIS,
   program:PROGRAM,mint:USDC,programSha256:artifact.sha256,owner:a.owner,worker:a.worker,
   checkpointSha256:report.checkpoint.sha256,receipts:Object.fromEntries(Object.entries(outbox).map(([id,row])=>[id,row.receipt])),
   reserveUsdc:s.reserveUsdc,remainingUsdc:s.remainingUsdc,workerUsdc:s.receiverUsdc,
   boundary:plan.boundary,mainnetTransactions:Object.values(outbox).filter(x=>x.receipt).length};
  durableJson(join(state,'proof.json'),proof);console.log(JSON.stringify(proof,null,2));
 }else if(command==='verify-guards'){
  if(!outbox.setup?.receipt)throw Error('Confirmed setup required');
  const s=await chainState(a),stage=s.delegation?'active':'revoked';
  const cases=s.delegation?[['over-remaining-cap',worker,s.remainingUsdc+1],['wrong-delegate',owner,1]]:[['revoked-worker',worker,1]];
  const checks=[];
  for(const [id,payer,amount] of cases){
   const ixs=await paymentInstructions(payer,a,amount,'0'.repeat(64),'research-001');
   const {lifetime}=await feeQuote(ixs,payer);
   const tx=await signedTransaction(ixs,payer,{...lifetime,lastValidBlockHeight:BigInt(lifetime.lastValidBlockHeight)});
   const sim=await rpc('simulateTransaction',[kit.getBase64EncodedWireTransaction(tx),{encoding:'base64',sigVerify:true,commitment:'confirmed'}]);
   if(!sim.value?.err)throw Error('Negative mainnet guard unexpectedly permitted; no broadcast');
   checks.push({id,amountUsdc:amount,error:sim.value.err,slot:sim.context.slot,broadcast:false});
  }
  const after=await chainState(a);
  if(after.reserveUsdc!==s.reserveUsdc||after.receiverUsdc!==s.receiverUsdc||after.remainingUsdc!==s.remainingUsdc)throw Error('Balance changed during read-only guard checks');
  const result={schema:'battery.mainnet-guard-simulations/1',observedAt:new Date().toISOString(),cluster:'mainnet',stage,checks,
   boundary:'Signed preflight simulations on actual mainnet accounts; not broadcast failed transactions.'};
  durableJson(join(state,'guards-'+stage+'.json'),result);console.log(JSON.stringify(result,null,2));
 }else if(command==='withdraw'){
  if(!plan.returnAddress)throw Error('User-bound return wallet required: return-address WALLET');
  if(await account(a.delegation))throw Error('Revoke the worker allowance first');
  for(const [id,payer,source] of [['return-owner',owner,a.sourceAta],['return-worker',worker,a.receiverAta]]){
   const amount=outbox[id]?.amountUsdc??decodeToken(await account(source),payer.address);
   if(!amount)continue;
   const [destination]=await token.findAssociatedTokenPda({owner:plan.returnAddress,mint:USDC,tokenProgram:token.TOKEN_PROGRAM_ADDRESS});
   // Keep receipt balance proof unambiguous; user-bound return wallet has a USDC ATA already.
   if(!await account(destination))throw Error('Return wallet must already have its canonical USDC ATA');
   await execute(id,await withdrawalInstructions(payer,source,plan.returnAddress,amount),payer,amount,hash(Buffer.from(plan.returnAddress)),plan.returnAddress);
  }
  console.log(JSON.stringify({returnedTo:plan.returnAddress,receipts:['return-owner','return-worker'].map(id=>outbox[id]?.receipt),
   note:'Token principal returned. Small SOL and account rent remain operator-owned; no automatic SOL sweep.'}));
 }else if(command==='revoke'){
  if(!outbox.setup?.receipt)throw Error('Confirmed setup required');
  const receipt=await execute('revoke',[revokeInstruction(owner,a)],owner);
  if(await account(a.delegation))throw Error('Delegation remains active');
  console.log(JSON.stringify({receipt,delegationClosed:true,
   remainingFunds:'Operator retains remaining USDC/SOL; withdrawal uses only the previously bound return address'}));
 }
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
